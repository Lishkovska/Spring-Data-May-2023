package com.example.springintrobookdatabase.model;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
