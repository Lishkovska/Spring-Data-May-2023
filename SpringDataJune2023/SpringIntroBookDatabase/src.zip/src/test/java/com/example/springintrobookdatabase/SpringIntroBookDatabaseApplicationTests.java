package com.example.springintrobookdatabase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIntroBookDatabaseApplicationTests {

    @Test
    void contextLoads() {
    }

}
