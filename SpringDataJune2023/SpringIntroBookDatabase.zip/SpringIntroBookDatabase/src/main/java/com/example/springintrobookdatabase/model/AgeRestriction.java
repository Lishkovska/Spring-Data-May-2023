package com.example.springintrobookdatabase.model;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
