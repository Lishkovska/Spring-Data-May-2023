package com.example.springintrobookdatabase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringIntroBookDatabaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringIntroBookDatabaseApplication.class, args);
    }

}
