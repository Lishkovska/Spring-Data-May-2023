package com.example.springadvancequeriesbookdb.entity;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
