package com.example.springadvancequeriesbookdb.entity;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
