package com.example.springadvancequeriesbookdb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAdvanceQueriesBookDbApplicationTests {

    @Test
    void contextLoads() {
    }

}
